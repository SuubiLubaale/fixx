package com.example.fixx.ui.theme.fragments.feeds

import android.os.Bundle
import android.os.Parcel
import android.os.Parcelable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import com.example.fixx.R
import com.example.fixx.databinding.FragmentFeedsWorkBinding
import com.example.fixx.ui.theme.adapters.FeedWorksRecyclerviewAdapter
import com.example.fixx.utils.StateListener
import com.example.fixx.utils.hide
import com.example.fixx.utils.log
import com.example.fixx.utils.show
import com.example.fixx.utils.toast
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class FeedsWorkFragment() : Fragment(), StateListener, Parcelable {

    private lateinit var binding: FragmentFeedsWorkBinding
    private val viewModel: FeedViewModel by activityViewModels()

    constructor(parcel: Parcel) : this() {

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = DataBindingUtil.inflate(inflater, R.layout.fragment_feeds_work, container, false)
        viewModel.stateListener = this

        initRecyclerview()

        return binding.root
    }

    private fun initRecyclerview() {
        viewModel.works.observe(viewLifecycleOwner) { works ->
            if (works.isNullOrEmpty()) binding.layoutNoWork.visibility = View.VISIBLE
            else {
                binding.layoutNoWork.visibility = View.GONE
                binding.recyclerviewFeedWork.adapter =
                    FeedWorksRecyclerviewAdapter(requireActivity(), works)
            }
        }
    }

    override fun onLoading() = binding.progressBarFeedWorks.show()

    override fun onSuccess(message: String) {
        binding.progressBarFeedWorks.hide()
        requireActivity().toast(message)
    }

    override fun onFailure(message: String) {
        binding.progressBarFeedWorks.hide()
        requireActivity().toast(message)
        requireActivity().log(message)
    }

    override fun writeToParcel(parcel: Parcel, flags: Int) {

    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<FeedsWorkFragment> {
        override fun createFromParcel(parcel: Parcel): FeedsWorkFragment {
            return FeedsWorkFragment(parcel)
        }

        override fun newArray(size: Int): Array<FeedsWorkFragment?> {
            return arrayOfNulls(size)
        }
    }

}