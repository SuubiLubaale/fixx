package com.example.fixx.ui.theme.fragments.feeds

import androidx.hilt.lifecycle.ViewModelInject
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.fixx.models.entities.Post
import com.example.fixx.models.entities.Work
import com.example.fixx.repository.PostRepository
import com.example.fixx.repository.WorkRepository
import com.example.fixx.utils.ApiException
import com.example.fixx.utils.Constants.INTERNET_MESSAGE
import com.example.fixx.utils.StateListener
import kotlinx.coroutines.launch
import java.net.UnknownHostException

@Suppress("DEPRECATION")
class FeedViewModel @ViewModelInject constructor(
    private val postRepository: PostRepository,
    private val workRepository: WorkRepository
) :
    ViewModel() {

    var stateListener: StateListener? = null

    private val _posts = MutableLiveData<List<Post>>()
    val posts: LiveData<List<Post>> = _posts

    private val _works = MutableLiveData<List<Work>>()
    val works: LiveData<List<Work>> = _works

    init {
        getUserWorks()
        getUserPosts()
    }

    private fun getUserPosts() {
        stateListener?.onLoading()

        viewModelScope.launch {
            try {
                val posts = postRepository.getUserPosts()
                _posts.value = posts
                stateListener?.onSuccess("Fetched")
                return@launch
            } catch (e: ApiException) {
                stateListener?.onFailure("${e.message}")
                return@launch
            } catch (e: UnknownHostException) {
                stateListener?.onFailure(INTERNET_MESSAGE)
                return@launch
            } catch (e: Exception) {
                stateListener?.onFailure("${e.message}")
                return@launch
            }
        }
    }

    private fun getUserWorks() {
        stateListener?.onLoading()

        viewModelScope.launch {
            try {
                val works = workRepository.getUserWorks()
                _works.value = works
                stateListener?.onSuccess("Fetched")
                return@launch
            } catch (e: ApiException) {
                stateListener?.onFailure("${e.message}")
                return@launch
            } catch (e: UnknownHostException) {
                stateListener?.onFailure(INTERNET_MESSAGE)
                return@launch
            } catch (e: Exception) {
                stateListener?.onFailure("${e.message}")
                return@launch
            }
        }
    }

}