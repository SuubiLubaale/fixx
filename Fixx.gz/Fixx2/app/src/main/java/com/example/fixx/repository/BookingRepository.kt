package com.example.fixx.repository

import android.util.Log
import androidx.lifecycle.MutableLiveData
import com.example.fixx.data.cache.AppDatabase
import com.example.fixx.data.network.ApiService
import com.example.fixx.models.entities.Booking
import com.example.fixx.models.network.BookWorkRequest
import com.example.fixx.models.network.UpdateBookingRequest
import com.example.fixx.models.network.UpdatePostRequest
import com.example.fixx.utils.Constants.ACCEPT
import com.example.fixx.utils.Constants.REJECT
import com.example.fixx.utils.SafeApiRequest
import javax.inject.Inject

class BookingRepository @Inject constructor(
    private val apiService: ApiService,
    private val appDatabase: AppDatabase,
    private val workRepository: WorkRepository
) : SafeApiRequest() {

    private val bookingsMutableLiveData = MutableLiveData<List<Booking>>()

    init {
        /*bookingsMutableLiveData.observeForever { bookings ->
            saveBookings(bookings)
        }*/
    }

    suspend fun getPostBookings(postId: Int) = safeApiRequest { apiService.getPostBooking(postId) }

    suspend fun bookWork(postId: Int, bid: String, comment: String) {
        val user = appDatabase.userDAO().getAuthenticatedUser()
        val token = "Bearer: ${user.token}"
        val userId = user.id

        val bookWorkRequestBody = BookWorkRequest(postId, userId, bid, comment)
        safeApiRequest { apiService.bookWork(token, bookWorkRequestBody) }
    }

    suspend fun acceptBooking(bookingId: Int, postId: Int, userId: Int): Booking {
        val updateBookingRequest = UpdateBookingRequest(workerId = userId, ACCEPT)
        val booking = safeApiRequest { apiService.updateBooking(bookingId, updateBookingRequest) }

        return booking
    }

    suspend fun rejectBooking(bookingId: Int, userId: Int) {
        val updateBookingRequest = UpdateBookingRequest(userId, REJECT)
        safeApiRequest { apiService.updateBooking(bookingId, updateBookingRequest) }
    }

    suspend fun updateBookedPost(postId: Int, workerId: Int, status: String, paid: Boolean) {
        val user = appDatabase.userDAO().getAuthenticatedUser()
        val userId = user.id

        val token = "Bearer: ${user.token}"
        val updatePostRequestBody = UpdatePostRequest(userId, workerId, status, paid)

        Log.e("VickiKbt", "Updating Booking Post")
        safeApiRequest { apiService.updatePost(token, postId, updatePostRequestBody) }
    }

    /*private fun saveBookings(booking: List<Booking>) {
        Coroutines.io {
            appDatabase.bookingDao().saveBookings(booking)
        }
    }*/

}