package com.example.fixx.models.network

import androidx.room.Entity
import com.example.fixx.models.entities.Post
import com.example.fixx.models.entities.User
import com.example.fixx.models.entities.Work
import com.google.gson.annotations.SerializedName

@Entity(tableName = "transactions_table")
data class TransactionResponse(
    //@PrimaryKey(autoGenerate = true)
    @SerializedName("id")
    val id: Int,

    @SerializedName("user_id")
    val userId: Int,

    @SerializedName("worker_id")
    val workerId: Int,

    @SerializedName("post_id")
    val postId: Int,

    @SerializedName("work_id")
    val workId: Int,

    @SerializedName("amount")
    val amount: String,

    @SerializedName("type")
    val type: String,

    @SerializedName("user")
    val user: User,

    @SerializedName("worker")
    val worker: User,

    @SerializedName("post")
    val post: Post,

    @SerializedName("work")
    val work: Work,

    @SerializedName("created_at")
    val createdAt: String
)