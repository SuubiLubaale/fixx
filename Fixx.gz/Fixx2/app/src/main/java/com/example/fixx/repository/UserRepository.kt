package com.example.fixx.repository

import androidx.lifecycle.MutableLiveData
import com.example.fixx.data.cache.AppDatabase
import com.example.fixx.data.network.ApiService
import com.example.fixx.data.preferences.TimePreference
import com.example.fixx.models.entities.Review
import com.example.fixx.models.entities.User
import com.example.fixx.models.entities.Work
import com.example.fixx.models.network.AuthResponse
import com.example.fixx.models.network.LoginRequest
import com.example.fixx.models.network.PhotoUploadResponse
import com.example.fixx.models.network.RegistrationRequest
import com.example.fixx.models.network.ReviewUserRequest
import com.example.fixx.utils.Coroutines
import com.example.fixx.utils.SafeApiRequest
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import okhttp3.MultipartBody
import javax.inject.Inject

class UserRepository @Inject constructor(
    private val apiService: ApiService,
    private val appDatabase: AppDatabase,
    private val timePreference: TimePreference
) : SafeApiRequest() {

    private val reviewMutableLiveData = MutableLiveData<List<Review>>()

    init {
        reviewMutableLiveData.observeForever { reviews ->
            saveAllReviews(reviews)
        }
    }

    suspend fun saveAuthenticatedUser(user: User) =
        appDatabase.userDAO().saveAuthenticatedUser(user)

    fun getAuthenticatedUser() = flow { emit(appDatabase.userDAO().getAuthenticatedUser()) }

    fun logoutUser() = appDatabase.clearAllTables()

    suspend fun loginUser(email: String, password: String): AuthResponse {
        val loginRequestBody = LoginRequest(email, password)

        return safeApiRequest { apiService.userLogin(loginRequestBody) }
    }


    private fun saveAllReviews(reviews: List<Review>) =
        Coroutines.io { appDatabase.reviewDao().saveAllReviews(reviews) }

    suspend fun getCurrentUserReviews(): Flow<MutableList<Review>> {
        val isReviewCacheAvailable = appDatabase.reviewDao().isReviewCacheAvailable() > 0

        if (isReviewCacheAvailable) return appDatabase.reviewDao().getAllReviews()

        //TODO: Add check internet connectivity
        val currentUserId = appDatabase.userDAO().getAuthenticatedUser().id
        val userReviewsResponse = safeApiRequest { apiService.getUserReviews(currentUserId) }
        reviewMutableLiveData.value = userReviewsResponse
        timePreference.saveReviewSyncTime(System.currentTimeMillis())

        return appDatabase.reviewDao().getAllReviews()
    }

    suspend fun fetchCurrentUserReviews() {
        val userId = appDatabase.userDAO().getAuthenticatedUser().id
        val reviewsRequest = safeApiRequest { apiService.getUserReviews(userId) }
        reviewMutableLiveData.value = reviewsRequest
        timePreference.saveReviewSyncTime(System.currentTimeMillis())
    }

    suspend fun registerUser(
        username: String,
        email: String,
        phoneNumber: String,
        imageUrl: String,
        specialisation: String,
        password: String,
        latitude: Double,
        longitude: Double,
        region: String,
        address: String,
        country: String
    ): AuthResponse {
        val registrationRequestBody = RegistrationRequest(
            username,
            email,
            phoneNumber,
            imageUrl,
            specialisation,
            password,
            latitude,
            longitude,
            region,
            address,
            country
        )

        return safeApiRequest { apiService.userRegistration(registrationRequestBody) }
    }

    suspend fun uploadProfilePicture(profilePicture: MultipartBody.Part): PhotoUploadResponse {
        return safeApiRequest { apiService.uploadProfilePicture(profilePicture) }
    }

    suspend fun fetchUser(id: Int) = safeApiRequest { apiService.getUser(id) }

    suspend fun fetchUserReviews(userId: Int) = safeApiRequest { apiService.getUserReviews(userId) }

    suspend fun reviewUser(work: Work, rating:Int, comment:String){
        val reviewUserRequest= ReviewUserRequest(work.userId,work.workerId,comment, rating)
        val token="Bearer: ${appDatabase.userDAO().getAuthenticatedUser().token}"
        safeApiRequest { apiService.reviewUser(token, reviewUserRequest) }
    }

}