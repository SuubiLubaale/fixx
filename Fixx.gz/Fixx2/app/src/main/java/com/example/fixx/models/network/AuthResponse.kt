package com.example.fixx.models.network

import com.example.fixx.models.entities.User

data class AuthResponse(
    val message: String,
    val user: User
)
