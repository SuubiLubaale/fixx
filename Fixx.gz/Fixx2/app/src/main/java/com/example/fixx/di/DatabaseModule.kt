package com.example.fixx.di

import android.app.Application
import androidx.room.Room
import com.example.fixx.data.cache.AppDatabase
import com.example.fixx.data.cache.daos.UserDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import javax.inject.Singleton

@InstallIn(ApplicationComponent::class)

@Module
object DatabaseModule {

    @Provides
    @Singleton
    fun providesAppDatabase(application: Application): AppDatabase {
        return Room.databaseBuilder(application, AppDatabase::class.java, "fixit.db")
            .fallbackToDestructiveMigration()
            .allowMainThreadQueries()
            .build()
    }

    @Provides
    @Singleton
    fun providesUserDAO(appDatabase: AppDatabase): UserDao {
        return appDatabase.userDAO()
    }

    /*@Provides
    @Singleton
    fun providesPostDAO(appDatabase: AppDatabase): PostDao {
        return appDatabase.postDao()
    }*/
}
