package com.example.fixx.repository

import android.util.Log
import com.example.fixx.data.cache.AppDatabase
import com.example.fixx.data.network.ApiService
import com.example.fixx.models.entities.Work
import com.example.fixx.models.network.WorkRequest
import com.example.fixx.models.network.WorkUpdateRequest
import com.example.fixx.utils.Constants.STATUS_COMPLETED
import com.example.fixx.utils.SafeApiRequest
import javax.inject.Inject

class WorkRepository @Inject constructor(
    private val apiService: ApiService,
    private val appDatabase: AppDatabase,
) : SafeApiRequest() {


    suspend fun getUserWorks(): List<Work> {
        val userId = appDatabase.userDAO().getAuthenticatedUser().id
        return safeApiRequest { apiService.getUserWorks(userId) }
    }

    suspend fun createWork(postId: Int, workerId: Int): Work {
        val user = appDatabase.userDAO().getAuthenticatedUser()

        val token = "Bearer: ${user.token}"
        val workRequest = WorkRequest(postId, user.id, workerId)

        Log.e("VickiKbt", "Work Repo: Work created")

        return safeApiRequest { apiService.createWork(token, workRequest) }
    }

    suspend fun getWork(postId: Int) = safeApiRequest { apiService.getWork(postId) }

    suspend fun updateWork(work: Work): Work {
        val workUpdateRequestBody = WorkUpdateRequest(work.postId, work.userId, work.workerId, STATUS_COMPLETED)
        //bookingRepository.updateBookedPost(work.postId, work.workerId, Constants.COMPLETED, false)
        return safeApiRequest { apiService.updateWork(work.id, workUpdateRequestBody) }
    }


}