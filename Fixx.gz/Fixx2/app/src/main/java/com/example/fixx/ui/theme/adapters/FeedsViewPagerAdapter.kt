package com.example.fixx.ui.theme.adapters

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter
import com.example.fixx.ui.theme.fragments.feeds.FeedsPostFragment
import com.example.fixx.ui.theme.fragments.feeds.FeedsWorkFragment

class FeedsViewPagerAdapter constructor(fragmentManager: FragmentManager) : FragmentPagerAdapter(
    fragmentManager,
    BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT
) {

    override fun getCount() = 2

    override fun getItem(position: Int): Fragment {
        return when (position) {
            0 -> FeedsPostFragment()
            else -> FeedsWorkFragment()
        }
    }

    override fun getPageTitle(position: Int): CharSequence? {
        return when (position) {
            0 -> "Posts"
            else -> "Work"
        }
    }

}