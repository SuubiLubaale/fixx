package com.example.fixx.data.cache

import androidx.room.Database
import androidx.room.RoomDatabase
import com.example.fixx.data.cache.daos.BookingsDao
import com.example.fixx.data.cache.daos.PostsDao
import com.example.fixx.data.cache.daos.ReviewsDao
import com.example.fixx.data.cache.daos.UserDao
import com.example.fixx.models.entities.Booking
import com.example.fixx.models.entities.Post
import com.example.fixx.models.entities.Review
import com.example.fixx.models.entities.User


@Database(
    entities = [User::class, Post::class, Review::class, Booking::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun userDAO(): UserDao
    abstract fun postDao(): PostsDao
    abstract fun reviewDao(): ReviewsDao
    abstract fun bookingDao(): BookingsDao

}