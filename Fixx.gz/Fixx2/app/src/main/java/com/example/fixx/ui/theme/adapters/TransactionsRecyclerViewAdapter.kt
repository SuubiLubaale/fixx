package com.example.fixx.ui.theme.adapters

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.example.fixx.R
import com.example.fixx.databinding.ItemTransactionBinding
import com.example.fixx.models.network.TransactionResponse
import com.example.fixx.utils.DataFormatter.Companion.dateFormatter

class TransactionsRecyclerviewAdapter constructor(private val transactionList: List<TransactionResponse>) :
    RecyclerView.Adapter<TransactionsViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TransactionsViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        val binding: ItemTransactionBinding =
            DataBindingUtil.inflate(inflater, R.layout.item_transaction, parent, false)

        return TransactionsViewHolder(binding)
    }

    override fun onBindViewHolder(holder: TransactionsViewHolder, position: Int) {
        val transaction = transactionList[position]

        holder.bind(transaction)

        holder.userName.setOnClickListener {
            //val action = TransactionsFragmentDirections.transactionToUserProfile(transaction.worker.id)
            //it.findNavController().navigate(action)
        }
    }

    override fun getItemCount() = transactionList.size
}

class TransactionsViewHolder(private val binding: ItemTransactionBinding) :
    RecyclerView.ViewHolder(binding.root) {

    val userName = binding.textViewName

    @SuppressLint("SetTextI18n")
    fun bind(transaction: TransactionResponse) {
        binding.textViewName.text = transaction.worker.username
        binding.textViewAmount.text = "Ksh. ${transaction.amount}"
        binding.textViewDate.text = dateFormatter(transaction.createdAt)

    }

}