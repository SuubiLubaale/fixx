package com.example.fixx.ui.theme.fragments.transactions

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.View.GONE
import android.view.View.VISIBLE
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.example.fixx.R
import com.example.fixx.databinding.FragmentTransactionsBinding
import com.example.fixx.ui.theme.adapters.TransactionsRecyclerviewAdapter
import com.example.fixx.utils.StateListener
import com.example.fixx.utils.hide
import com.example.fixx.utils.log
import com.example.fixx.utils.show
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class TransactionsFragment : Fragment(), StateListener {

    private lateinit var binding: FragmentTransactionsBinding
    private val viewModel by viewModels<TransactionViewModel>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding =
            DataBindingUtil.inflate(inflater, R.layout.fragment_transactions, container, false)
        viewModel.stateListener = this

        initUI()

        return binding.root
    }

    private fun initUI() {
        viewModel.getUserTransactions().observe(viewLifecycleOwner) { transactions ->
            if (transactions.isNullOrEmpty()) binding.layoutNoTransactions.visibility = VISIBLE
            else {
                binding.layoutNoTransactions.visibility = GONE
                binding.recyclerviewTransactions.adapter =
                    TransactionsRecyclerviewAdapter(transactions)
            }
        }

    }

    override fun onLoading() {
        binding.progressBarTransaction.show()
    }

    override fun onSuccess(message: String) {
        binding.progressBarTransaction.hide()
        requireActivity().log(message)
    }

    override fun onFailure(message: String) {
        binding.progressBarTransaction.hide()
        requireActivity().log(message)
    }
}