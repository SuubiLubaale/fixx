package com.example.fixx.repository

import com.example.fixx.data.cache.AppDatabase
import com.example.fixx.data.network.ApiService
import com.example.fixx.models.network.TransactionRequest
import com.example.fixx.models.network.TransactionResponse
import com.example.fixx.utils.SafeApiRequest
import javax.inject.Inject

class TransactionRepository @Inject constructor(
    private val apiService: ApiService,
    private val appDatabase: AppDatabase
) : SafeApiRequest() {

    suspend fun getUserTransactions(): List<TransactionResponse> {
        val user = appDatabase.userDAO().getAuthenticatedUser()
        val userId = user.id
        val token = "Bearer: ${user.token}"

        return safeApiRequest { apiService.getUserTransactions(token, userId) }
    }

    suspend fun createTransaction(
        postId: Int,
        amount: String,
        type: String,
        workId: Int,
        workerId: Int
    ): TransactionResponse {
        val user = appDatabase.userDAO().getAuthenticatedUser()
        val userId = user.id
        val token = "Bearer: ${user.token}"
        val transactionRequest = TransactionRequest(amount, postId, type, userId, workId, workerId)

        return safeApiRequest { apiService.createTransaction(token, transactionRequest) }
    }

}