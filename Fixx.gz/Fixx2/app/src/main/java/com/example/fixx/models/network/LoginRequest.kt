package com.example.fixx.models.network

data class LoginRequest(
    val email:String,
    val password:String
)