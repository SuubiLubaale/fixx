package com.example.fixx.ui.theme.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.example.fixx.R
import com.example.fixx.databinding.ItemReviewBinding
import com.example.fixx.models.entities.Review

class ReviewsRecyclerviewAdapter constructor(
    private val reviewList: List<Review>
) : RecyclerView.Adapter<ReviewRecyclerviewViewHolder>() {

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): ReviewRecyclerviewViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)
        val binding: ItemReviewBinding = DataBindingUtil.inflate(layoutInflater, R.layout.item_review, parent, false)

        return ReviewRecyclerviewViewHolder(binding)
    }

    override fun getItemCount() = reviewList.size

    override fun onBindViewHolder(holder: ReviewRecyclerviewViewHolder, position: Int) {
        val review = reviewList[position]

        holder.bind(review)
    }
}

class ReviewRecyclerviewViewHolder(private val binding: ItemReviewBinding) :
    RecyclerView.ViewHolder(binding.root) {


    fun bind(review: Review) {
        binding.ratingBarReview.rating = review.rating.toFloat()
        binding.textViewRating.text=review.rating.toString()
        binding.textViewReview.text = review.comment
    }

}