package com.example.fixx.ui.theme.fragments.work

import androidx.hilt.lifecycle.ViewModelInject
import androidx.lifecycle.ViewModel
import androidx.lifecycle.liveData
import androidx.lifecycle.viewModelScope
import com.example.fixx.models.entities.Work
import com.example.fixx.repository.BookingRepository
import com.example.fixx.repository.UserRepository
import com.example.fixx.repository.WorkRepository
import com.example.fixx.utils.ApiException
import com.example.fixx.utils.Constants
import com.example.fixx.utils.StateListener
import kotlinx.coroutines.launch
import java.net.UnknownHostException

@Suppress("DEPRECATION")
class WorkViewModel @ViewModelInject constructor(
    private val workRepository: WorkRepository,
    private val userRepository: UserRepository,
    private val bookingRepository: BookingRepository
) :
    ViewModel() {

    var stateListener: StateListener? = null

    fun getWork(postId: Int) = liveData {
        stateListener?.onLoading()

        try {
            val work = workRepository.getWork(postId)
            work.let {
                emit(it)
                stateListener?.onSuccess("Fetched work")
            }
            return@liveData

        } catch (e: ApiException) {
            //stateListener?.onFailure("${e.message}")
            return@liveData
        } catch (e: UnknownHostException) {
            stateListener?.onFailure("${e.message}")
            return@liveData
        } catch (e: Exception) {
            stateListener?.onFailure("${e.message}")
            return@liveData
        }
    }

    fun createWork(postId: Int, userId: Int) = liveData {
        stateListener?.onLoading()

        try {
            val work = workRepository.createWork(postId, workerId = userId)
            work.let {
                emit(it)
                stateListener?.onSuccess("Created work")
            }
            return@liveData
        } catch (e: ApiException) {
            stateListener?.onFailure("${e.message}")
            return@liveData
        } catch (e: UnknownHostException) {
            stateListener?.onFailure("${e.message}")
            return@liveData
        } catch (e: Exception) {
            stateListener?.onFailure("${e.message}")
            return@liveData
        }
    }

    fun updateWork(work: Work) = liveData {
        stateListener?.onLoading()

        try {
            val workUpdateResponse = workRepository.updateWork(work)
            workUpdateResponse.let { work ->
                bookingRepository.updateBookedPost(
                    work.postId,
                    work.workerId,
                    Constants.STATUS_COMPLETED,
                    false
                )
                emit(work)
                stateListener?.onSuccess("Updated work to complete")
                return@liveData
            }
        } catch (e: ApiException) {
            stateListener?.onFailure("${e.message}")
            return@liveData
        } catch (e: UnknownHostException) {
            stateListener?.onFailure("${e.message}")
            return@liveData
        } catch (e: Exception) {
            stateListener?.onFailure("${e.message}")
            return@liveData
        }
    }

    fun reviewUser(work: Work, rating: Int, comment: String) {
        stateListener?.onLoading()

        viewModelScope.launch {
            try {
                userRepository.reviewUser(work, rating, comment)
                //stateListener?.onSuccess("Rated ${work.worker.username} with $rating because: $comment")
                stateListener?.onSuccess("Rated")
                return@launch
            } catch (e: ApiException) {
                stateListener?.onFailure("${e.message}")
                return@launch
            } catch (e: UnknownHostException) {
                stateListener?.onFailure("${e.message}")
                return@launch
            } catch (e: Exception) {
                stateListener?.onFailure("${e.message}")
                return@launch
            }
        }
    }
}