package com.example.fixx.di

import android.app.Application
import com.example.fixx.data.preferences.TimePreference
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn

@InstallIn(ApplicationComponent::class)

@Module
object PreferencesModule {

    @Provides
    fun providesTimePreference(application: Application): TimePreference {
        return TimePreference(application)
    }
}