package com.example.fixx.ui.theme.adapters

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.fixx.R
import com.example.fixx.databinding.ItemHomeBinding
import com.example.fixx.models.entities.Work
import com.example.fixx.utils.DataFormatter.Companion.dateFormatter

class FeedWorksRecyclerviewAdapter constructor(
    private val context: Context,
    private val worksList: List<Work>
) : RecyclerView.Adapter<FeedWorkRecyclerviewViewHolder>() {

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): FeedWorkRecyclerviewViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)
        val binding: ItemHomeBinding =
            DataBindingUtil.inflate(layoutInflater, R.layout.item_home, parent, false)

        return FeedWorkRecyclerviewViewHolder(binding)
    }

    override fun getItemCount() = worksList.size

    override fun onBindViewHolder(holder: FeedWorkRecyclerviewViewHolder, position: Int) {
        val post = worksList[position]

        holder.bind(post, context)

    }

}

class FeedWorkRecyclerviewViewHolder(private val binding: ItemHomeBinding) :
    RecyclerView.ViewHolder(binding.root) {

    @SuppressLint("SetTextI18n")
    fun bind(work: Work, context: Context) {
        Glide.with(context).load(work.post.imageUrl)
            .placeholder(R.drawable.imageview_placeholder)
            .error(R.drawable.imageview_placeholder)
            .into(binding.postImageView)

        Glide.with(context).load(work.user.imageUrl).into(binding.postUserImageView)
        binding.postUserUsername.text = work.user.username
        binding.postDate.text = dateFormatter(work.createdAt)
        binding.postLocationTextView.text = "${work.post.region}, ${work.post.country}"
        binding.postCategoryTextView.text = work.post.category
        binding.postDescriptionTextView.text = work.post.description
    }

}