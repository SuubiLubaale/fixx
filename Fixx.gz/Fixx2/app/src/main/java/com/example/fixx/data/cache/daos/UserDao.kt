@file:Suppress("AndroidUnresolvedRoomSqlReference")

package com.example.fixx.data.cache.daos

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.fixx.models.entities.User

@Dao
interface UserDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveAuthenticatedUser(user: User)

    @Query("SELECT * FROM user_table")
    fun getAuthenticatedUser(): User

    //@Query("DELETE FROM user_table")
    //suspend fun deleteAuthenticatedUser()

}