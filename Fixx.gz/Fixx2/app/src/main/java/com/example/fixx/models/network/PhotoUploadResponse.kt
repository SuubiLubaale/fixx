package com.example.fixx.models.network

data class PhotoUploadResponse(
    //@SerializedName("image_url")
    val imageURL: String
)